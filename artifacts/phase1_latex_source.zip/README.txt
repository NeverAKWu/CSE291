Phase 1 report - Option 5, Group 8

Main document: report.tex
Upload this ZIP to Overleaf and select report.tex as the main document.
Use pdfLaTeX or XeLaTeX; preserve revised/figs/ paths.
The source follows the teammate template: 10pt, two columns, Letter, Times.
The compiled report has 2 main pages plus a timeline/fault-definition appendix.
Local build: tectonic --untrusted report.tex
